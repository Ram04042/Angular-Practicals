export class User {
    User_id: String;
    Name: String;
    Email_ID: String;
    Phone_No: Number;
    DOB: Date;
    Address: String;
    Password: String;
}
